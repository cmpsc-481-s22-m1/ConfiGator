# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['configator']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'configator',
    'version': '0.1.0',
    'description': 'Simple Python project template',
    'long_description': None,
    'author': 'Adam Shinomiya',
    'author_email': 'shinomiyaa@allegheny.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
